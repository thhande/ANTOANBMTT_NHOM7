package com.elgamal;

import java.math.BigInteger;

/**
 * Represents an ElGamal digital signature (r, s).
 */
public class ElGamalSignature {
    private final BigInteger r;
    private final BigInteger s;

    public ElGamalSignature(BigInteger r, BigInteger s) {
        this.r = r;
        this.s = s;
    }

    public BigInteger getR() { return r; }
    public BigInteger getS() { return s; }

    @Override
    public String toString() {
        return "r = " + r.toString(16).toUpperCase() + "\ns = " + s.toString(16).toUpperCase();
    }
}
