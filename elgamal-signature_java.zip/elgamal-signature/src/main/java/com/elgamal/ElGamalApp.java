package com.elgamal;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.math.BigInteger;

/**
 * ElGamal Digital Signature App — Swing UI
 */
public class ElGamalApp extends JFrame {

    // ── Palette ──────────────────────────────────────────────────────────────
    private static final Color BG_DARK    = new Color(0x0D, 0x11, 0x17);   // near-black navy
    private static final Color BG_PANEL   = new Color(0x13, 0x1A, 0x24);   // deep panel
    private static final Color BG_FIELD   = new Color(0x0A, 0x0E, 0x14);   // input sink
    private static final Color ACCENT     = new Color(0x00, 0xB4, 0xFF);   // electric blue
    private static final Color ACCENT_DIM = new Color(0x00, 0x5F, 0x8A);   // muted blue
    private static final Color SUCCESS    = new Color(0x00, 0xE5, 0x7A);   // emerald green
    private static final Color DANGER     = new Color(0xFF, 0x45, 0x4F);   // alert red
    private static final Color TEXT_PRI   = new Color(0xE8, 0xEF, 0xF8);   // primary text
    private static final Color TEXT_SEC   = new Color(0x6A, 0x82, 0x9C);   // secondary text
    private static final Color BORDER     = new Color(0x1E, 0x2C, 0x3F);   // subtle border

    // ── Fonts ─────────────────────────────────────────────────────────────────
    private static final Font MONO   = new Font("Monospaced", Font.PLAIN, 11);
    private static final Font MONO_B = new Font("Monospaced", Font.BOLD,  12);
    private static final Font SANS   = new Font("SansSerif",  Font.PLAIN, 13);
    private static final Font SANS_B = new Font("SansSerif",  Font.BOLD,  13);
    private static final Font TITLE  = new Font("SansSerif",  Font.BOLD,  22);
    private static final Font LABEL  = new Font("SansSerif",  Font.BOLD,  11);

    // ── State ─────────────────────────────────────────────────────────────────
    private final ElGamal elgamal = new ElGamal(512);
    private ElGamalSignature currentSignature = null;

    // ── Key panel widgets ──────────────────────────────────────────────────────
    private JTextArea taP, taG, taX, taY;
    private JLabel lblKeyStatus;
    private JComboBox<String> cbBitLength;

    // ── Sign panel widgets ─────────────────────────────────────────────────────
    private JTextArea taMessage;
    private JTextArea taSigR, taSigS;
    private JLabel lblSignStatus;

    // ── Verify panel widgets ───────────────────────────────────────────────────
    private JTextArea taVerifyMessage;
    private JTextArea taVerifyR, taVerifyS;
    private JLabel lblVerifyResult;

    // ── Log ───────────────────────────────────────────────────────────────────
    private JTextArea taLog;

    // ─────────────────────────────────────────────────────────────────────────
    public ElGamalApp() {
        setTitle("ElGamal Digital Signature");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(980, 760);
        setMinimumSize(new Dimension(820, 640));
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_DARK);
        setLayout(new BorderLayout(0, 0));

        add(buildHeader(), BorderLayout.NORTH);

        JTabbedPane tabs = buildTabs();
        add(tabs, BorderLayout.CENTER);

        add(buildLogPanel(), BorderLayout.SOUTH);

        setVisible(true);
        log("Welcome to ElGamal Digital Signature Tool. Generate keys to begin.");
    }

    // ── Header ────────────────────────────────────────────────────────────────
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(BG_PANEL);
        header.setBorder(new MatteBorder(0, 0, 1, 0, BORDER));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 14));
        left.setOpaque(false);

        // Lock icon placeholder (Unicode)
        JLabel icon = new JLabel("🔐");
        icon.setFont(new Font("SansSerif", Font.PLAIN, 22));
        left.add(icon);

        JPanel titleGroup = new JPanel();
        titleGroup.setOpaque(false);
        titleGroup.setLayout(new BoxLayout(titleGroup, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("ElGamal Digital Signature");
        title.setFont(TITLE);
        title.setForeground(TEXT_PRI);
        titleGroup.add(title);

        JLabel subtitle = new JLabel("Asymmetric cryptographic signing & verification");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 12));
        subtitle.setForeground(TEXT_SEC);
        titleGroup.add(subtitle);

        left.add(titleGroup);
        header.add(left, BorderLayout.WEST);

        // Status chip
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 18));
        right.setOpaque(false);
        lblKeyStatus = styledLabel("No Keys Generated", TEXT_SEC, LABEL);
        right.add(lblKeyStatus);
        header.add(right, BorderLayout.EAST);

        return header;
    }

    // ── Tabs ──────────────────────────────────────────────────────────────────
    private JTabbedPane buildTabs() {
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(BG_DARK);
        tabs.setForeground(TEXT_PRI);
        tabs.setFont(SANS_B);

        // Use custom UI for nicer tabs
        UIManager.put("TabbedPane.selected", BG_PANEL);
        UIManager.put("TabbedPane.background", BG_DARK);
        UIManager.put("TabbedPane.foreground", TEXT_PRI);
        UIManager.put("TabbedPane.focus", ACCENT);

        tabs.addTab("  Key Generation  ", buildKeyPanel());
        tabs.addTab("  Sign Message    ", buildSignPanel());
        tabs.addTab("  Verify Signature", buildVerifyPanel());

        tabs.setBackgroundAt(0, BG_PANEL);
        tabs.setBackgroundAt(1, BG_PANEL);
        tabs.setBackgroundAt(2, BG_PANEL);

        return tabs;
    }

    // ── Key Generation Panel ──────────────────────────────────────────────────
    private JPanel buildKeyPanel() {
        JPanel outer = darkPanel(new BorderLayout(0, 16));
        outer.setBorder(new EmptyBorder(20, 24, 20, 24));

        // Top controls
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        controls.setOpaque(false);

        controls.add(sectionLabel("Key Size:"));

        cbBitLength = new JComboBox<>(new String[]{"256-bit (Demo)", "512-bit (Standard)", "1024-bit (Strong)"});
        cbBitLength.setSelectedIndex(1);
        styleCombo(cbBitLength);
        controls.add(cbBitLength);

        JButton btnGenerate = accentButton("Generate Key Pair");
        controls.add(Box.createHorizontalStrut(12));
        controls.add(btnGenerate);

        JButton btnClear = ghostButton("Clear Keys");
        controls.add(btnClear);

        outer.add(controls, BorderLayout.NORTH);

        // Key display grid
        JPanel grid = new JPanel(new GridLayout(2, 2, 14, 14));
        grid.setOpaque(false);

        taP = keyField("p  —  Prime Modulus");
        taG = keyField("g  —  Generator");
        taX = keyField("x  —  Private Key  (keep secret!)");
        taY = keyField("y  —  Public Key");

        grid.add(wrapKeyField("PRIME  p", taP, ACCENT_DIM));
        grid.add(wrapKeyField("GENERATOR  g", taG, ACCENT_DIM));
        grid.add(wrapKeyField("PRIVATE KEY  x  ⚠  SECRET", taX, DANGER));
        grid.add(wrapKeyField("PUBLIC KEY  y", taY, SUCCESS));

        outer.add(grid, BorderLayout.CENTER);

        // Theory note
        JLabel note = new JLabel("<html><body style='color:#6A829C;font-size:11px;'>"
            + "<b style='color:#00B4FF'>How it works:</b>  "
            + "Choose prime <i>p</i>, generator <i>g</i>, private key <i>x</i>.  "
            + "Compute public key <i>y = g<sup>x</sup> mod p</i>.  "
            + "Share <i>(p, g, y)</i> openly; keep <i>x</i> secret."
            + "</body></html>");
        outer.add(note, BorderLayout.SOUTH);

        // Actions
        btnGenerate.addActionListener(e -> generateKeys());
        btnClear.addActionListener(e -> clearKeys());

        return outer;
    }

    // ── Sign Panel ────────────────────────────────────────────────────────────
    private JPanel buildSignPanel() {
        JPanel outer = darkPanel(new BorderLayout(0, 16));
        outer.setBorder(new EmptyBorder(20, 24, 20, 24));

        // Message input
        JPanel top = darkPanel(new BorderLayout(0, 8));
        top.add(sectionLabel("Message to Sign"), BorderLayout.NORTH);
        taMessage = new JTextArea(4, 40);
        styleTextArea(taMessage);
        taMessage.setLineWrap(true);
        taMessage.setWrapStyleWord(true);
        taMessage.setFont(SANS);
        JScrollPane spMsg = styledScroll(taMessage);
        top.add(spMsg, BorderLayout.CENTER);

        // Button row
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 4));
        btnRow.setOpaque(false);
        JButton btnSign = accentButton("Sign Message");
        JButton btnCopySig = ghostButton("Copy Signature");
        lblSignStatus = styledLabel("", TEXT_SEC, SANS);
        btnRow.add(btnSign);
        btnRow.add(btnCopySig);
        btnRow.add(lblSignStatus);
        top.add(btnRow, BorderLayout.SOUTH);

        outer.add(top, BorderLayout.NORTH);

        // Signature output
        JPanel sigPanel = darkPanel(new GridLayout(1, 2, 14, 0));
        taSigR = new JTextArea();
        taSigS = new JTextArea();
        styleTextArea(taSigR);
        styleTextArea(taSigS);
        taSigR.setFont(MONO);
        taSigS.setFont(MONO);
        taSigR.setEditable(false);
        taSigS.setEditable(false);

        sigPanel.add(wrapKeyField("SIGNATURE  r", taSigR, ACCENT));
        sigPanel.add(wrapKeyField("SIGNATURE  s", taSigS, ACCENT));

        outer.add(sigPanel, BorderLayout.CENTER);

        // Theory note
        JLabel note = new JLabel("<html><body style='color:#6A829C;font-size:11px;'>"
            + "<b style='color:#00B4FF'>Signing:</b>  "
            + "Hash message → <i>m</i>.  "
            + "Pick random <i>k</i> with gcd(<i>k</i>, <i>p−1</i>) = 1.  "
            + "Compute <i>r = g<sup>k</sup> mod p</i>,  "
            + "<i>s = k<sup>−1</sup>(m − xr) mod (p−1)</i>.  "
            + "Signature is <i>(r, s)</i>."
            + "</body></html>");
        outer.add(note, BorderLayout.SOUTH);

        // Actions
        btnSign.addActionListener(e -> signMessage());
        btnCopySig.addActionListener(e -> copySig());

        return outer;
    }

    // ── Verify Panel ──────────────────────────────────────────────────────────
    private JPanel buildVerifyPanel() {
        JPanel outer = darkPanel(new BorderLayout(0, 16));
        outer.setBorder(new EmptyBorder(20, 24, 20, 24));

        // Message
        JPanel top = darkPanel(new BorderLayout(0, 8));
        top.add(sectionLabel("Message to Verify"), BorderLayout.NORTH);
        taVerifyMessage = new JTextArea(3, 40);
        styleTextArea(taVerifyMessage);
        taVerifyMessage.setLineWrap(true);
        taVerifyMessage.setWrapStyleWord(true);
        taVerifyMessage.setFont(SANS);
        top.add(styledScroll(taVerifyMessage), BorderLayout.CENTER);
        outer.add(top, BorderLayout.NORTH);

        // Sig input
        JPanel sigInput = darkPanel(new GridLayout(1, 2, 14, 0));
        taVerifyR = new JTextArea();
        taVerifyS = new JTextArea();
        styleTextArea(taVerifyR);
        styleTextArea(taVerifyS);
        taVerifyR.setFont(MONO);
        taVerifyS.setFont(MONO);

        sigInput.add(wrapKeyField("SIGNATURE  r  (paste hex)", taVerifyR, ACCENT));
        sigInput.add(wrapKeyField("SIGNATURE  s  (paste hex)", taVerifyS, ACCENT));
        outer.add(sigInput, BorderLayout.CENTER);

        // Actions + result
        JPanel bottomRow = darkPanel(new BorderLayout(14, 0));
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        btnRow.setOpaque(false);

        JButton btnVerify = accentButton("Verify Signature");
        JButton btnPasteFromSign = ghostButton("← Paste Last Signature");
        btnRow.add(btnVerify);
        btnRow.add(btnPasteFromSign);
        bottomRow.add(btnRow, BorderLayout.WEST);

        lblVerifyResult = new JLabel("—  Awaiting input");
        lblVerifyResult.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblVerifyResult.setForeground(TEXT_SEC);
        lblVerifyResult.setBorder(new EmptyBorder(8, 12, 8, 0));
        bottomRow.add(lblVerifyResult, BorderLayout.CENTER);

        // Theory note
        JLabel note = new JLabel("<html><body style='color:#6A829C;font-size:11px;'>"
            + "<b style='color:#00B4FF'>Verification:</b>  "
            + "Check <i>g<sup>m</sup> ≡ y<sup>r</sup> · r<sup>s</sup> (mod p)</i>.  "
            + "Only a valid signature from the correct private key satisfies this."
            + "</body></html>");

        JPanel south = darkPanel(new BorderLayout(0, 8));
        south.add(bottomRow, BorderLayout.NORTH);
        south.add(note, BorderLayout.SOUTH);
        outer.add(south, BorderLayout.SOUTH);

        btnVerify.addActionListener(e -> verifySignature());
        btnPasteFromSign.addActionListener(e -> pasteSignatureToVerify());

        return outer;
    }

    // ── Log Panel ─────────────────────────────────────────────────────────────
    private JPanel buildLogPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BG_PANEL);
        panel.setBorder(new MatteBorder(1, 0, 0, 0, BORDER));
        panel.setPreferredSize(new Dimension(0, 110));

        JLabel logTitle = new JLabel("  ACTIVITY LOG");
        logTitle.setFont(LABEL);
        logTitle.setForeground(ACCENT_DIM);
        logTitle.setBorder(new EmptyBorder(6, 10, 4, 0));
        panel.add(logTitle, BorderLayout.NORTH);

        taLog = new JTextArea();
        taLog.setEditable(false);
        taLog.setBackground(BG_FIELD);
        taLog.setForeground(TEXT_SEC);
        taLog.setFont(MONO);
        taLog.setBorder(new EmptyBorder(4, 10, 4, 10));
        JScrollPane sp = new JScrollPane(taLog);
        sp.setBorder(BorderFactory.createEmptyBorder(0, 8, 8, 8));
        sp.getViewport().setBackground(BG_FIELD);
        panel.add(sp, BorderLayout.CENTER);

        return panel;
    }

    // ── Logic ─────────────────────────────────────────────────────────────────
    private void generateKeys() {
        int bits = switch (cbBitLength.getSelectedIndex()) {
            case 0 -> 256;
            case 2 -> 1024;
            default -> 512;
        };

        lblKeyStatus.setText("Generating...");
        lblKeyStatus.setForeground(ACCENT);

        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            ElGamal tmp;
            @Override protected Void doInBackground() {
                tmp = new ElGamal(bits);
                tmp.generateKeys();
                return null;
            }
            @Override protected void done() {
                try {
                    get(); // rethrow exceptions
                    elgamal.loadKeys(tmp.getP(), tmp.getG(), tmp.getX(), tmp.getY());
                    taP.setText(elgamal.getP().toString(16).toUpperCase());
                    taG.setText(elgamal.getG().toString(16).toUpperCase());
                    taX.setText(elgamal.getX().toString(16).toUpperCase());
                    taY.setText(elgamal.getY().toString(16).toUpperCase());
                    lblKeyStatus.setText("✓  " + bits + "-bit Keys Active");
                    lblKeyStatus.setForeground(SUCCESS);
                    log("[KEY GEN]  Generated " + bits + "-bit ElGamal key pair successfully.");
                    currentSignature = null;
                } catch (Exception ex) {
                    lblKeyStatus.setText("Key generation failed");
                    lblKeyStatus.setForeground(DANGER);
                    log("[ERROR]  Key generation failed: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private void clearKeys() {
        taP.setText(""); taG.setText(""); taX.setText(""); taY.setText("");
        taSigR.setText(""); taSigS.setText("");
        lblKeyStatus.setText("No Keys Generated");
        lblKeyStatus.setForeground(TEXT_SEC);
        currentSignature = null;
        log("[CLEAR]  Keys cleared.");
    }

    private void signMessage() {
        if (!elgamal.hasKeys()) {
            showError("Generate keys first.");
            return;
        }
        String msg = taMessage.getText().trim();
        if (msg.isEmpty()) {
            showError("Enter a message to sign.");
            return;
        }

        lblSignStatus.setText("Signing...");
        lblSignStatus.setForeground(ACCENT);

        SwingWorker<ElGamalSignature, Void> worker = new SwingWorker<>() {
            @Override protected ElGamalSignature doInBackground() throws Exception {
                return elgamal.sign(msg);
            }
            @Override protected void done() {
                try {
                    currentSignature = get();
                    taSigR.setText(currentSignature.getR().toString(16).toUpperCase());
                    taSigS.setText(currentSignature.getS().toString(16).toUpperCase());
                    lblSignStatus.setText("✓  Signed");
                    lblSignStatus.setForeground(SUCCESS);
                    log("[SIGN]  Message signed successfully. Signature (r, s) generated.");
                } catch (Exception ex) {
                    lblSignStatus.setText("Signing failed");
                    lblSignStatus.setForeground(DANGER);
                    log("[ERROR]  Signing failed: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private void copySig() {
        if (currentSignature == null) { showError("No signature to copy."); return; }
        String text = "r=" + currentSignature.getR().toString(16).toUpperCase()
                    + "\ns=" + currentSignature.getS().toString(16).toUpperCase();
        Toolkit.getDefaultToolkit().getSystemClipboard()
            .setContents(new java.awt.datatransfer.StringSelection(text), null);
        log("[COPY]  Signature copied to clipboard.");
    }

    private void pasteSignatureToVerify() {
        if (currentSignature == null) { showError("Sign a message first."); return; }
        taVerifyMessage.setText(taMessage.getText());
        taVerifyR.setText(currentSignature.getR().toString(16).toUpperCase());
        taVerifyS.setText(currentSignature.getS().toString(16).toUpperCase());
        log("[PASTE]  Last signature pasted into verification panel.");
    }

    private void verifySignature() {
        if (!elgamal.hasKeys()) { showError("Generate keys first."); return; }
        String msg  = taVerifyMessage.getText().trim();
        String rHex = taVerifyR.getText().trim().replaceAll("\\s+", "");
        String sHex = taVerifyS.getText().trim().replaceAll("\\s+", "");

        if (msg.isEmpty() || rHex.isEmpty() || sHex.isEmpty()) {
            showError("Fill in message, r, and s.");
            return;
        }

        try {
            BigInteger r = new BigInteger(rHex, 16);
            BigInteger s = new BigInteger(sHex, 16);
            ElGamalSignature sig = new ElGamalSignature(r, s);
            boolean valid = elgamal.verify(msg, sig);

            if (valid) {
                lblVerifyResult.setText("✓  VALID — Signature is authentic");
                lblVerifyResult.setForeground(SUCCESS);
                log("[VERIFY]  ✓ Signature VALID. Message is authentic and untampered.");
            } else {
                lblVerifyResult.setText("✗  INVALID — Signature does not match");
                lblVerifyResult.setForeground(DANGER);
                log("[VERIFY]  ✗ Signature INVALID. Message may be altered or wrong key.");
            }
        } catch (Exception ex) {
            lblVerifyResult.setText("✗  Error parsing signature");
            lblVerifyResult.setForeground(DANGER);
            log("[ERROR]  Verification error: " + ex.getMessage());
        }
    }

    // ── UI Helpers ────────────────────────────────────────────────────────────
    private JPanel darkPanel(LayoutManager lm) {
        JPanel p = new JPanel(lm);
        p.setBackground(BG_DARK);
        return p;
    }

    private JTextArea keyField(String tooltip) {
        JTextArea ta = new JTextArea();
        styleTextArea(ta);
        ta.setFont(MONO);
        ta.setEditable(false);
        ta.setToolTipText(tooltip);
        return ta;
    }

    private JPanel wrapKeyField(String labelText, JTextArea ta, Color accentColor) {
        JPanel wrapper = new JPanel(new BorderLayout(0, 6));
        wrapper.setBackground(BG_PANEL);
        wrapper.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(accentColor.darker(), 1, true),
            new EmptyBorder(10, 12, 10, 12)
        ));

        JLabel lbl = new JLabel(labelText);
        lbl.setFont(LABEL);
        lbl.setForeground(accentColor);
        wrapper.add(lbl, BorderLayout.NORTH);

        JScrollPane sp = new JScrollPane(ta);
        sp.setBorder(BorderFactory.createEmptyBorder());
        sp.getViewport().setBackground(BG_FIELD);
        sp.setBackground(BG_FIELD);
        wrapper.add(sp, BorderLayout.CENTER);

        return wrapper;
    }

    private void styleTextArea(JTextArea ta) {
        ta.setBackground(BG_FIELD);
        ta.setForeground(TEXT_PRI);
        ta.setCaretColor(ACCENT);
        ta.setSelectionColor(ACCENT_DIM);
        ta.setBorder(new EmptyBorder(4, 6, 4, 6));
        ta.setFont(MONO);
    }

    private JScrollPane styledScroll(JComponent c) {
        JScrollPane sp = new JScrollPane(c);
        sp.setBackground(BG_FIELD);
        sp.getViewport().setBackground(BG_FIELD);
        sp.setBorder(new LineBorder(BORDER, 1, true));
        return sp;
    }

    private JButton accentButton(String text) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isPressed()) {
                    g2.setColor(ACCENT_DIM);
                } else if (getModel().isRollover()) {
                    g2.setColor(ACCENT.brighter());
                } else {
                    g2.setColor(ACCENT);
                }
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 8, 8));
                g2.setColor(BG_DARK);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int tx = (getWidth() - fm.stringWidth(getText())) / 2;
                int ty = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), tx, ty);
                g2.dispose();
            }
        };
        btn.setFont(SANS_B);
        btn.setForeground(BG_DARK);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(170, 34));
        return btn;
    }

    private JButton ghostButton(String text) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = getModel().isRollover() ? new Color(0x1E, 0x2C, 0x3F) : BG_PANEL;
                g2.setColor(bg);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 8, 8));
                g2.setColor(BORDER);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 8, 8));
                g2.setColor(TEXT_SEC);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int tx = (getWidth() - fm.stringWidth(getText())) / 2;
                int ty = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), tx, ty);
                g2.dispose();
            }
        };
        btn.setFont(SANS);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(170, 34));
        return btn;
    }

    private JLabel styledLabel(String text, Color color, Font font) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(font);
        lbl.setForeground(color);
        return lbl;
    }

    private JLabel sectionLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(LABEL);
        lbl.setForeground(TEXT_SEC);
        return lbl;
    }

    private void styleCombo(JComboBox<String> cb) {
        cb.setBackground(BG_FIELD);
        cb.setForeground(TEXT_PRI);
        cb.setFont(SANS);
        cb.setBorder(new LineBorder(BORDER, 1));
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void log(String msg) {
        SwingUtilities.invokeLater(() -> {
            taLog.append(msg + "\n");
            taLog.setCaretPosition(taLog.getDocument().getLength());
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    public static void main(String[] args) {
        // Dark mode look and feel tweaks
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        UIManager.put("OptionPane.background", new Color(0x13, 0x1A, 0x24));
        UIManager.put("Panel.background",      new Color(0x13, 0x1A, 0x24));
        UIManager.put("OptionPane.messageForeground", new Color(0xE8, 0xEF, 0xF8));

        SwingUtilities.invokeLater(ElGamalApp::new);
    }
}
