package com.elgamal;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.SecureRandom;

/**
 * ElGamal Digital Signature Scheme
 *
 * Key generation:
 *   - Choose large prime p, generator g of Z*_p
 *   - Choose private key x in [1, p-2]
 *   - Compute public key y = g^x mod p
 *
 * Signing message M:
 *   - Hash M to get m = H(M)
 *   - Choose random k in [1, p-2] with gcd(k, p-1) = 1
 *   - Compute r = g^k mod p
 *   - Compute s = k^-1 * (m - x*r) mod (p-1)
 *   - Signature is (r, s)
 *
 * Verification:
 *   - Check g^m ≡ y^r * r^s (mod p)
 */
public class ElGamal {

    private final SecureRandom random = new SecureRandom();

    // Key components
    private BigInteger p;   // large prime
    private BigInteger g;   // generator
    private BigInteger x;   // private key
    private BigInteger y;   // public key: y = g^x mod p

    // Bit length for the prime (512 for demo, 1024+ for production)
    private int bitLength;

    public ElGamal(int bitLength) {
        this.bitLength = bitLength;
    }

    /**
     * Generate key pair.
     */
    public void generateKeys() {
        // 1. Generate a large safe prime p (p = 2q+1 where q is also prime)
        //    Using BigInteger's built-in prime generation for simplicity
        p = BigInteger.probablePrime(bitLength, random);

        // 2. Find a generator g of Z*_p
        //    For a prime p, we can use g=2 or find a primitive root
        //    For simplicity and speed, we use a commonly accepted generator
        g = findGenerator(p);

        // 3. Choose private key x in [1, p-2]
        BigInteger pMinus2 = p.subtract(BigInteger.TWO);
        do {
            x = new BigInteger(bitLength, random);
        } while (x.compareTo(BigInteger.ONE) < 0 || x.compareTo(pMinus2) > 0);

        // 4. Compute public key y = g^x mod p
        y = g.modPow(x, p);
    }

    /**
     * Find a generator for Z*_p.
     * For a prime p, any value from 2 to p-1 is likely a generator.
     * We pick a small value and verify basic properties.
     */
    private BigInteger findGenerator(BigInteger prime) {
        BigInteger pMinus1 = prime.subtract(BigInteger.ONE);
        for (int candidate = 2; candidate < 100; candidate++) {
            BigInteger gen = BigInteger.valueOf(candidate);
            // Check gen^((p-1)/2) != 1 mod p (not a QR, more likely primitive root)
            // For simplicity, just use a valid small generator
            if (gen.modPow(pMinus1.divide(BigInteger.TWO), prime).compareTo(BigInteger.ONE) != 0) {
                return gen;
            }
        }
        return BigInteger.valueOf(2);
    }

    /**
     * Sign a message using the ElGamal signature scheme.
     *
     * @param message the plaintext message to sign
     * @return ElGamalSignature containing (r, s)
     */
    public ElGamalSignature sign(String message) throws Exception {
        if (p == null) throw new IllegalStateException("Keys not generated yet");

        // Hash the message
        BigInteger m = hashMessage(message, p);

        BigInteger pMinus1 = p.subtract(BigInteger.ONE);
        BigInteger r, s, k;

        // Keep trying until we get valid s != 0
        do {
            // Choose random k with gcd(k, p-1) = 1
            do {
                k = new BigInteger(bitLength - 1, random);
                // ensure k in [1, p-2]
                k = k.mod(pMinus1.subtract(BigInteger.ONE)).add(BigInteger.ONE);
            } while (!k.gcd(pMinus1).equals(BigInteger.ONE));

            // r = g^k mod p
            r = g.modPow(k, p);

            // s = k^-1 * (m - x*r) mod (p-1)
            BigInteger kInv = k.modInverse(pMinus1);
            BigInteger xr = x.multiply(r).mod(pMinus1);
            BigInteger mMinusXr = m.subtract(xr).mod(pMinus1);
            // Ensure positive result
            if (mMinusXr.signum() < 0) {
                mMinusXr = mMinusXr.add(pMinus1);
            }
            s = kInv.multiply(mMinusXr).mod(pMinus1);

        } while (s.equals(BigInteger.ZERO));

        return new ElGamalSignature(r, s);
    }

    /**
     * Verify an ElGamal signature.
     *
     * @param message   the plaintext message
     * @param signature the signature (r, s)
     * @return true if valid, false otherwise
     */
    public boolean verify(String message, ElGamalSignature signature) throws Exception {
        if (p == null) throw new IllegalStateException("Keys not generated yet");

        BigInteger r = signature.getR();
        BigInteger s = signature.getS();

        // Validate r: 0 < r < p
        if (r.compareTo(BigInteger.ZERO) <= 0 || r.compareTo(p) >= 0) return false;
        // Validate s: 0 < s < p-1
        if (s.compareTo(BigInteger.ZERO) <= 0 || s.compareTo(p.subtract(BigInteger.ONE)) >= 0) return false;

        // Hash the message
        BigInteger m = hashMessage(message, p);

        // Verify: g^m ≡ y^r * r^s (mod p)
        BigInteger lhs = g.modPow(m, p);
        BigInteger yr  = y.modPow(r, p);
        BigInteger rs  = r.modPow(s, p);
        BigInteger rhs = yr.multiply(rs).mod(p);

        return lhs.equals(rhs);
    }

    /**
     * Hash a message into Z*_p using SHA-256.
     */
    private BigInteger hashMessage(String message, BigInteger prime) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(message.getBytes("UTF-8"));
        BigInteger m = new BigInteger(1, hash); // positive
        return m.mod(prime.subtract(BigInteger.ONE)).add(BigInteger.ONE); // in [1, p-1]
    }

    // Getters
    public BigInteger getP() { return p; }
    public BigInteger getG() { return g; }
    public BigInteger getX() { return x; }
    public BigInteger getY() { return y; }
    public int getBitLength() { return bitLength; }

    public boolean hasKeys() { return p != null; }

    /**
     * Load keys externally (for manual key input or import).
     */
    public void loadKeys(BigInteger p, BigInteger g, BigInteger x, BigInteger y) {
        this.p = p;
        this.g = g;
        this.x = x;
        this.y = y;
    }
}
