# ElGamal Digital Signature App

A Java/Swing application implementing the ElGamal digital signature scheme.

## Requirements

- Java 17+ (JDK)
- Maven 3.6+ (or build manually with javac)

## Build & Run

### Option A — Maven (recommended)
```bash
cd elgamal-signature
mvn package
java -jar target/elgamal-signature.jar
```

### Option B — Manual compile
```bash
mkdir -p out
find src -name "*.java" | xargs javac -d out
java -cp out com.elgamal.ElGamalApp
```

## How ElGamal Digital Signatures Work

### Key Generation
1. Choose a large prime **p** and a generator **g** of Z*_p
2. Choose private key **x** ∈ [1, p−2]
3. Compute public key **y = g^x mod p**
4. Public: (p, g, y) | Private: x

### Signing a Message M
1. Hash M to get m = SHA-256(M) mod (p−1)
2. Choose random k ∈ [1, p−2] with gcd(k, p−1) = 1
3. Compute r = g^k mod p
4. Compute s = k⁻¹ · (m − x·r) mod (p−1)
5. Signature is **(r, s)**

### Verification
Check: **g^m ≡ y^r · r^s (mod p)**

## Project Structure

```
src/main/java/com/elgamal/
├── ElGamal.java           # Core cryptography implementation
├── ElGamalSignature.java  # Signature data class (r, s)
└── ElGamalApp.java        # Swing UI application
```

## Security Notes

- 512-bit keys are suitable for demonstration only
- Use 2048-bit or larger for production use
- The private key **x** must be kept secret
- Each signature uses a fresh random k — never reuse k (breaks security)
- This implementation uses SHA-256 for message hashing
